//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

for x in 0..<10 {
    x * x
}



var blue = UIColor.blue
var red = UIColor.red

var lbl = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 30))
lbl.text = "Ciao a tutti"
lbl.textColor = blue

var img = UIImage(named: "swift-hero.png")

var iv = UIImageView(image: img)





