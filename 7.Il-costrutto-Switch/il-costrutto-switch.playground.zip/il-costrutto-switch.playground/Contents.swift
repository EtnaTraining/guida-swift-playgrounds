// Playground - noun: a place where people can play

import Foundation

var operazione: Character = "x"
var a = 10, b = 5
switch operazione {
case "+":
    print("\(a) + \(b) = \(a+b)")
case "-":
    print("\(a) - \(b) = \(a-b)")
case "x":
    print("\(a) x \(b) = \(a*b)")
case "/":
    print("\(a) / \(b) = \(a/b)")
default:
    print("operazione non valida")
}

var lettera: Character = "b"
switch lettera {
case "a","e","i","o","u":
    print("\(lettera) è una vocale")
case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
    print("\(lettera) è una consonante")
default:
    print("\(lettera) non è ne una vocale ne una consonante")
}

var numero: Int = 32
switch numero {
case 1...100:
    print("\(numero) è compreso tra 0 e 100")
case 101...1000:
    print("\(numero) è compreso tra 101 e 1000")
default:
    print("\(numero) è minore di 0 o maggiore di 1000")
}


switch numero {
case let x where x > 0:
    print("x maggiore di 0: \(x)")
case let x where x < 0:
    print("x minore di 0")
case _:
    print("x è uguale a 0")
}

var punto = (4, 2)

switch punto {
case (0,0):
    print("angolo in basso a sx")
case (4,4):
    print("angolo in alto a dx")
case (4,0):
    print("angolo in basso a dx")
case (0,4):
    print("angolo in alto a sx")
case (_,4):
    print("lato superiore")
case (4, _):
    print("lato sinistro")
case (0, _):
    print("lato destro")
case (_, 0):
    print("lato inferiore")
default:
    print("dentro o fuori dai bordi")
}

switch punto {
case (let x, 4):
    print("sul lato superiore, con x = \(x)")
case (4, let y):
    print("sul lato sinistro, con y = \(y)")
case (0, let y):
    print("sul lato destro, con y = \(y)")
case (let x, 0):
    print("sul lato inferiore, con x = \(x)")
default:
    print("dentro o fuori dai bordi")
}

punto = (4, 7)
switch punto {
case (let x, 4) where x >= 0:
    print("sul lato superiore, con x = \(x)")
case (4, let y) where y >= 0:
    print("sul lato sinistro, con y = \(y)")
case (0, let y) where y >= 0:
    print("sul lato destro, con y = \(y)")
case (let x, 0) where x >= 0:
    print("sul lato inferiore, con x = \(x)")
default:
    print("dentro o fuori dai bordi")
}

punto = (0, 5)
switch punto {
case (0,0):
    print("angolo in basso a sx")
case (4,4):
    print("angolo in alto a dx")
case (4,0):
    print("angolo in basso a dx")
case (0,4):
    print("angolo in alto a sx")
case (let x, 4) where x >= 0 && x <= 4:
    print("sul lato superiore, con x = \(x)")
case (4, let y) where y >= 0 && y <= 4:
    print("sul lato destro, con y = \(y)")
case (0, let y) where y >= 0 && y <= 4:
    print("sul lato sinistro, con y = \(y)")
case (let x, 0) where x >= 0 && x <= 4:
    print("sul lato inferiore, con x = \(x)")
default:
    print("dentro o fuori dai bordi")
}

numero = 33
switch numero {
case let x where x % 2 == 0:
    print("\(x) è divisibile per 2")
case let x where x % 2 != 0:
    print("\(x) non è divisibile per 2")
    fallthrough
default:
    print("ma è un numero intero")
}


numero = 35
switch numero {
case let x where x % 3 == 0:
    break
case let x where x % 2 == 0:
    print("\(x) è divisibile per 2")
case let x where x % 2 != 0:
    print("\(x) non è divisibile per 2")
default:
    break
}

