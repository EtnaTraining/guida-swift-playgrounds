// Playground - noun: a place where people can play

import Foundation

func stampa(messaggio: String) {
    print(messaggio)
}

stampa(messaggio: "ciao a tutti")

func ripetiStampa(messaggio: String, ripetizioni: Int) {
    for _ in 0...ripetizioni {
        stampa(messaggio: messaggio)
    }
}

ripetiStampa(messaggio: "hello world", ripetizioni: 5)

// etichette degli argomenti

func saluta(con m: String, ripeti r: Int) {
    for _ in 0...r {
        print(m)
    }
}

saluta(con: "hola a todos", ripeti: 5)

func sayHello(_ message: String, repetition: Int) {
    for _ in 0...repetition {
        print(message)
    }
}
sayHello("Good Morning", repetition: 3)

// Valori di ritorno

func somma(a: Int, b: Int) -> Int {
    return a+b
}
print(somma(a: 3,b: 5))

func stampa2(msg: String) -> Void {
    print(msg)
}

// Valore di default

func saluta(messaggio: String = "Buongiorno", nome: String) {
    print("\(messaggio), \(nome)!")
}

saluta(nome: "Francesco")

// Il tipo funzione

func divisione(primoOp: Int, secondoOp: Int) -> Int? {
    if secondoOp == 0 { return nil }
    return primoOp / secondoOp
}

divisione(primoOp: 5, secondoOp: 2)
var operazioneMatematica: (Int, Int) -> Int? = divisione
divisione(primoOp: 5, secondoOp: 2)

func swap(_ a: inout Int, _ b: inout Int) {
    let temp = a
    a = b
    b = temp
}

var firstValue = 5
var secondValue = 18
print("\(firstValue) \(secondValue)")
swap(&firstValue, &secondValue)
print("\(firstValue) \(secondValue)")


// Tuple

let serverResponse: (Int, String) = (400, "Not found")
print(serverResponse.0)
print(serverResponse.1)

let (statusCode, errorMessage) = (400, "Not Found")
if statusCode != 200 {
    print("Error: \(errorMessage)")
}

var p1 = (0, 4)
var p2 = (3, 5)
var p3 = (2, 5)

func baricentro(a: (Int, Int), b: (Int,Int), c: (Int, Int)) -> (Float, Float) {
    let x = a.0 + b.0 + c.0
    let y = a.1 + b.1 + c.1
    return (Float(x)/3, Float(y)/3)
}

baricentro(a: p1, b: p2, c: p3)

var p4 = (x: 3, y: 5)
var p5 = (x: 6, y: 12)


func distanza(a: (x:Int, y:Int), b: (x:Int, y:Int)) -> Float {
    let dx = powf(Float(b.x - a.x), 2.0)
    let dy = powf(Float(b.y - a.y), 2.0)
    let d = sqrt(dx + dy)
    return d
}

distanza(a: p4, b: p5)

